from ourapp import db
from flask_login import UserMixin
